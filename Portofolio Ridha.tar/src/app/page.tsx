"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  Phone,
  Mail,
  MapPin,
  Globe,
  Download,
  ArrowUp,
  Briefcase,
  GraduationCap,
  BadgeCheck,
  Sparkles,
  Wrench,
  Languages,
  FileSpreadsheet,
  Database,
  HeartHandshake,
  CalendarDays,
  ChevronRight,
  Factory,
  Building2,
  Cpu,
  Award,
  Menu,
  X,
} from "lucide-react";

/* ============================== DATA ============================== */

const NAV_LINKS = [
  { id: "tentang", label: "Tentang" },
  { id: "pengalaman", label: "Pengalaman" },
  { id: "pendidikan", label: "Pendidikan" },
  { id: "keahlian", label: "Keahlian" },
  { id: "sertifikasi", label: "Sertifikasi" },
  { id: "kontak", label: "Kontak" },
];

const CONTACTS = [
  { icon: Phone, label: "Telepon / WA", value: "0859-5110-3445", href: "tel:+6285951103445" },
  { icon: Mail, label: "Email", value: "ridhanuzuliani3@gmail.com", href: "mailto:ridhanuzuliani3@gmail.com" },
  { icon: MapPin, label: "Alamat", value: "Jl. Klamono Raya No. 148, Curug, Cimanggis, Depok 16453", href: undefined },
  { icon: Globe, label: "Website Portofolio", value: "Portofolio Online — buka tautan", href: "https://preview-chat-f4e57784-ceb0-4fdc-b39a-e7a912f6a5d3.space-z.ai" },
];

const EXPERIENCES = [
  {
    icon: Factory,
    role: "Operation Production Sub Section",
    company: "PT Indonesia Epson Industri",
    period: "MAR 2024 – JAN 2026",
    bullets: [
      "Input data serial produk setelah proses assembly selesai.",
      "Perakitan produk model sesuai dengan rencana produksi harian.",
      "Pelaksanaan stock taking (penghitungan persediaan) berkala.",
      "Memilah data dan menyusun laporan part NG dan OK.",
      "Menguasai pemahaman produk model baru dengan cepat.",
    ],
  },
  {
    icon: Building2,
    role: "SA — Sales Administrator",
    company: "PT Rancang Indah Sentosa",
    period: "JAN 2022 – MEI 2023",
    bullets: [
      "Penyusunan laporan penjualan harian menggunakan Microsoft Excel.",
      "Pengembalian produk NG (not good) ke supplier.",
      "Pengajuan permintaan (request) produk ke supplier.",
      "Penetapan target penjualan setiap bulan.",
    ],
  },
  {
    icon: Building2,
    role: "SA — Sales Administrator",
    company: "PT Home Credit Indonesia",
    period: "SEP 2021 – JAN 2022",
    bullets: [
      "Input data pelanggan yang mengajukan pembiayaan.",
      "Penawaran produk jasa pembiayaan kepada konsumen.",
    ],
  },
];

const EDUCATIONS = [
  {
    period: "SEP 2022 – AGU 2026",
    degree: "S1 Teknologi Informasi (S.Kom)",
    school: "Universitas Bina Sarana Informatika",
    note: "Fokus kajian: computer vision dan pembelajaran machine learning.",
  },
  {
    period: "JUL 2018 – MEI 2021",
    degree: "SMA — Program Studi IPS",
    school: "SMAN 88 Jakarta",
    note: undefined,
  },
];

const SKILLS = [
  { label: "Microsoft Excel", value: 90 },
  { label: "Microsoft Word & PowerPoint", value: 85 },
  { label: "Figma & UI/UX", value: 80 },
  { label: "Python", value: 75 },
  { label: "C++", value: 70 },
  { label: "SPSS", value: 65 },
];

const TOOLS = ["VSCode", "Canva Design", "CapCut"];
const DOMAINS = ["Machine Learning", "Computer Vision", "Pengolahan Data", "Administrasi & Pengarsipan", "Penyusunan Laporan"];
const SOFT_SKILLS = ["Keterampilan Komunikasi", "Negosiasi", "Kerjasama", "Kreativitas", "Problem Solving"];
const LANGUAGES = [
  { name: "Bahasa Indonesia", level: "Mahir", pct: 95 },
  { name: "Bahasa Inggris", level: "Menengah", pct: 60 },
];

const CERTS = [
  {
    name: "TOEFL",
    issuer: "Universitas Bina Sarana Informatika",
    period: "MAR 2026 – MAR 2028",
  },
  {
    name: "Analyst Program",
    issuer: "BNSP — Badan Nasional Sertifikasi Profesi",
    period: "SEP 2025 – SEP 2028",
  },
  {
    name: "Cybersecurity Course",
    issuer: "Universitas Bina Sarana Informatika",
    period: "NOV 2024 – NOV 2027",
  },
];

const HIGHLIGHTS = [
  { icon: Briefcase, title: "3+ Tahun", desc: "Pengalaman produksi & penjualan" },
  { icon: FileSpreadsheet, title: "Excel 90%", desc: "Pelaporan & entri data" },
  { icon: Cpu, title: "S.Kom — TI", desc: "Fokus computer vision & ML" },
];

/* ============================ UTILITIES ============================ */

function useActiveSection(ids: string[]) {
  const [active, setActive] = useState(ids[0]);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) setActive(entry.target.id);
        }
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [ids]);
  return active;
}

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 },
};

function SectionHeader({
  kicker,
  title,
  desc,
}: {
  kicker: string;
  title: string;
  desc?: string;
}) {
  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.5 }}
      variants={fadeUp}
      className="text-center max-w-2xl mx-auto"
    >
      <span className="inline-flex items-center gap-1.5 rounded-full bg-toska-100 text-toska-800 text-xs font-semibold tracking-widest uppercase px-4 py-1.5">
        <Sparkles className="size-3.5" aria-hidden />
        {kicker}
      </span>
      <h2 className="font-heading mt-4 text-3xl sm:text-4xl font-extrabold text-ink">{title}</h2>
      <div className="mx-auto mt-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-toska-800 to-toska-600" aria-hidden />
      {desc ? <p className="mt-4 text-ink-soft leading-relaxed">{desc}</p> : null}
    </motion.div>
  );
}

function SkillBar({ label, value }: { label: string; value: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) setInView(true);
      },
      { threshold: 0.4 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} className="group">
      <div className="flex items-center justify-between mb-2">
        <span className="font-medium text-ink text-sm sm:text-[15px]">{label}</span>
        <span className="text-sm font-bold text-toska-800 tabular-nums">{value}%</span>
      </div>
      <div className="h-2.5 rounded-full bg-toska-100 overflow-hidden" role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-toska-800 to-toska-600"
          initial={{ width: 0 }}
          animate={{ width: inView ? `${value}%` : 0 }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.15 }}
        />
      </div>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-toska-200 bg-toska-50 px-3.5 py-1.5 text-sm font-medium text-toska-900 transition-colors hover:bg-toska-100">
      {children}
    </span>
  );
}

/* ============================== PAGE ============================== */

export default function Home() {
  const active = useActiveSection(NAV_LINKS.map((l) => l.id));
  const [menuOpen, setMenuOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 480);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-paper text-ink">
      {/* ================= NAVBAR ================= */}
      <header className="fixed top-0 inset-x-0 z-50 border-b border-toska-100/80 bg-paper/85 backdrop-blur-md">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6" aria-label="Navigasi utama">
          <a href="#beranda" className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-toska-800 font-heading text-sm font-extrabold text-white shadow-sm">
              RN
            </span>
            <span className="font-heading text-sm font-bold text-ink hidden sm:block">
              Ridha Nuzuliani
            </span>
          </a>
          <ul className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map((l) => (
              <li key={l.id}>
                <a
                  href={`#${l.id}`}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                    active === l.id
                      ? "bg-toska-800 text-white"
                      : "text-ink-soft hover:bg-toska-100 hover:text-toska-900"
                  }`}
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="hidden md:block">
            <a
              href="/cv-full.pdf"
              download="CV Full.pdf"
              className="inline-flex items-center gap-2 rounded-full bg-toska-800 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-toska-900"
            >
              <Download className="size-4" aria-hidden />
              Unduh CV
            </a>
          </div>
          <button
            type="button"
            className="md:hidden grid size-10 place-items-center rounded-xl border border-toska-200 bg-white text-toska-800"
            onClick={() => setMenuOpen((v) => !v)}
            aria-expanded={menuOpen}
            aria-label={menuOpen ? "Tutup menu" : "Buka menu"}
          >
            {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </nav>
        {menuOpen ? (
          <div className="md:hidden border-t border-toska-100 bg-paper px-4 pb-4 pt-2">
            <ul className="flex flex-col gap-1">
              {NAV_LINKS.map((l) => (
                <li key={l.id}>
                  <a
                    href={`#${l.id}`}
                    onClick={() => setMenuOpen(false)}
                    className={`block rounded-xl px-4 py-2.5 text-sm font-medium ${
                      active === l.id ? "bg-toska-800 text-white" : "text-ink-soft hover:bg-toska-100"
                    }`}
                  >
                    {l.label}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <a
                  href="/cv-full.pdf"
                  download="CV Full.pdf"
                  className="flex items-center justify-center gap-2 rounded-xl bg-toska-800 px-4 py-2.5 text-sm font-semibold text-white"
                >
                  <Download className="size-4" aria-hidden />
                  Unduh CV
                </a>
              </li>
            </ul>
          </div>
        ) : null}
      </header>

      {/* ================= HERO ================= */}
      <main className="flex-1">
        <section id="beranda" className="relative overflow-hidden pt-28 pb-16 sm:pt-36 sm:pb-24">
          <div className="dot-grid absolute inset-0" aria-hidden />
          <div className="absolute -top-24 -right-24 size-96 rounded-full bg-toska-100 blur-3xl opacity-70" aria-hidden />
          <div className="absolute -bottom-32 -left-24 size-96 rounded-full bg-toska-50 blur-3xl" aria-hidden />

          <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
            <div className="flex flex-col items-center text-center">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="relative"
              >
                <div className="absolute -inset-2.5 rounded-[2rem] bg-gradient-to-br from-toska-600 to-toska-800 opacity-20 rotate-3" aria-hidden />
                <div className="absolute -inset-2.5 rounded-[2rem] border-2 border-toska-200" aria-hidden />
                <div className="relative size-44 sm:size-52 overflow-hidden rounded-[2rem] border-4 border-white shadow-xl">
                  <Image
                    src="/profile-cv.jpg"
                    alt="Foto CV Ridha Nuzuliani, S.Kom — potret formal dengan latar merah"
                    fill
                    priority
                    sizes="(max-width: 640px) 176px, 208px"
                    className="object-cover object-top"
                  />
                </div>
                <span className="absolute -bottom-3 -right-3 grid size-12 place-items-center rounded-2xl bg-toska-800 text-white shadow-lg" aria-hidden>
                  <GraduationCap className="size-6" />
                </span>
              </motion.div>

              <motion.div
                initial="hidden"
                animate="visible"
                transition={{ staggerChildren: 0.12, delayChildren: 0.2 }}
                className="mt-8 flex flex-col items-center"
              >
                <motion.span variants={fadeUp} className="inline-flex items-center gap-2 rounded-full border border-toska-200 bg-white px-4 py-1.5 text-xs font-semibold text-toska-800 shadow-sm">
                  <span className="relative flex size-2" aria-hidden>
                    <span className="absolute inline-flex size-full animate-ping rounded-full bg-toska-600 opacity-60" />
                    <span className="relative inline-flex size-2 rounded-full bg-toska-800" />
                  </span>
                  Terbuka untuk peluang karier baru
                </motion.span>

                <motion.h1 variants={fadeUp} className="font-heading mt-5 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-ink">
                  Ridha Nuzuliani, <span className="text-toska-800">S.Kom</span>
                </motion.h1>

                <motion.p variants={fadeUp} className="mt-4 text-lg sm:text-xl font-semibold text-toska-900">
                  Staff Operasional Produksi
                  <span className="mx-2 text-toska-600" aria-hidden>·</span>
                  <span className="text-ink-soft font-medium">Pengolahan Data &amp; Administrasi</span>
                </motion.p>

                <motion.p variants={fadeUp} className="mt-5 max-w-2xl text-ink-soft leading-relaxed">
                  Profesional berorientasi detail dengan pengalaman lebih dari 3 tahun di bidang
                  produksi dan penjualan — terampil dalam operasi perakitan, pengendalian
                  inventaris, dan pelaporan berbasis data.
                </motion.p>

                <motion.div variants={fadeUp} className="mt-8 flex flex-wrap items-center justify-center gap-3">
                  <a
                    href="#kontak"
                    className="inline-flex items-center gap-2 rounded-full bg-toska-800 px-6 py-3 text-sm font-semibold text-white shadow-md shadow-toska-800/20 transition hover:-translate-y-0.5 hover:bg-toska-900"
                  >
                    <Mail className="size-4" aria-hidden />
                    Hubungi Saya
                  </a>
                  <a
                    href="/cv-full.pdf"
                    download="CV Full.pdf"
                    className="inline-flex items-center gap-2 rounded-full border border-toska-200 bg-white px-6 py-3 text-sm font-semibold text-toska-800 shadow-sm transition hover:-translate-y-0.5 hover:bg-toska-50"
                  >
                    <Download className="size-4" aria-hidden />
                    Unduh CV (PDF)
                  </a>
                </motion.div>
              </motion.div>
            </div>

            {/* highlight cards */}
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              transition={{ staggerChildren: 0.1 }}
              className="mt-14 grid gap-4 sm:grid-cols-3"
            >
              {HIGHLIGHTS.map((h) => (
                <motion.div
                  key={h.title}
                  variants={fadeUp}
                  className="flex items-center gap-4 rounded-2xl border border-toska-100 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
                >
                  <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-toska-100 text-toska-800" aria-hidden>
                    <h.icon className="size-6" />
                  </span>
                  <div>
                    <p className="font-heading font-bold text-ink">{h.title}</p>
                    <p className="text-sm text-ink-soft">{h.desc}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ================= TENTANG ================= */}
        <section id="tentang" className="py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <SectionHeader
              kicker="Profil Profesional"
              title="Tentang Saya"
              desc="Kombinasi pengalaman operasional lapangan dan latar belakang teknologi informasi."
            />
            <div className="mt-12 grid gap-6 lg:grid-cols-5">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.5 }}
                variants={fadeUp}
                className="lg:col-span-3 rounded-3xl border border-toska-100 bg-white p-7 sm:p-9 shadow-sm"
              >
                <p className="text-ink-soft leading-relaxed text-[15px] sm:text-base">
                  Profesional yang berorientasi pada detail dengan pengalaman lebih dari 3 tahun di
                  bidang produksi dan penjualan, terampil dalam operasi perakitan, pengendalian
                  inventaris, dan layanan yang bersentuhan langsung dengan pelanggan. Mahir
                  menggunakan Microsoft Excel untuk pelaporan dan entri data, serta berpengalaman
                  praktis dengan Python, C++, Figma, dan SPSS. Penyandang gelar Sarjana Komputer
                  (S.Kom) bidang Teknologi Informasi dengan fokus kajian computer vision dan
                  machine learning — mampu menyajikan data produksi secara akurat, mengefisienkan
                  alur pelaporan, dan mendukung tim lintas fungsi dalam mencapai target harian.
                </p>
                <div className="mt-6 flex flex-wrap gap-2.5">
                  {DOMAINS.map((d) => (
                    <Tag key={d}>{d}</Tag>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.5, delay: 0.1 }}
                variants={fadeUp}
                className="lg:col-span-2 rounded-3xl bg-toska-800 p-7 sm:p-9 text-white shadow-md shadow-toska-800/20"
              >
                <h3 className="font-heading text-lg font-bold">Informasi Singkat</h3>
                <ul className="mt-5 space-y-4">
                  {[
                    { k: "Nama Lengkap", v: "Ridha Nuzuliani, S.Kom" },
                    { k: "Domisili", v: "Curug, Cimanggis, Depok" },
                    { k: "Pendidikan Terakhir", v: "S1 Teknologi Informasi" },
                    { k: "Bidang Utama", v: "Operasional Produksi & Data" },
                  ].map((r) => (
                    <li key={r.k} className="flex items-start justify-between gap-4 border-b border-white/15 pb-4 last:border-0 last:pb-0">
                      <span className="text-sm text-toska-200">{r.k}</span>
                      <span className="text-sm font-semibold text-right">{r.v}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ================= PENGALAMAN ================= */}
        <section id="pengalaman" className="bg-white py-16 sm:py-24 border-y border-toska-100">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <SectionHeader
              kicker="Rekam Jejak"
              title="Pengalaman Kerja"
              desc="Tiga perusahaan, satu tujuan: operasional yang akurat, tertib data, dan target harian yang tercapai."
            />
            <div className="relative mx-auto mt-14 max-w-3xl">
              <div className="absolute left-[22px] top-2 bottom-2 w-0.5 bg-gradient-to-b from-toska-600 via-toska-200 to-transparent sm:left-[26px]" aria-hidden />
              <ol className="space-y-8">
                {EXPERIENCES.map((exp, i) => (
                  <motion.li
                    key={exp.company}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-60px" }}
                    transition={{ duration: 0.5, delay: i * 0.08 }}
                    variants={fadeUp}
                    className="relative pl-16 sm:pl-20"
                  >
                    <span className="absolute left-0 top-0 grid size-11 sm:size-[52px] place-items-center rounded-2xl bg-toska-800 text-white shadow-md shadow-toska-800/25" aria-hidden>
                      <exp.icon className="size-5 sm:size-6" />
                    </span>
                    <div className="rounded-3xl border border-toska-100 bg-paper p-6 sm:p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <h3 className="font-heading text-lg font-bold text-ink">{exp.role}</h3>
                          <p className="mt-0.5 text-sm font-semibold text-toska-800">{exp.company}</p>
                        </div>
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-toska-100 px-3.5 py-1.5 text-xs font-bold text-toska-900 whitespace-nowrap">
                          <CalendarDays className="size-3.5" aria-hidden />
                          {exp.period}
                        </span>
                      </div>
                      <ul className="mt-4 space-y-2.5">
                        {exp.bullets.map((b) => (
                          <li key={b} className="flex items-start gap-2.5 text-sm text-ink-soft leading-relaxed">
                            <ChevronRight className="mt-0.5 size-4 shrink-0 text-toska-600" aria-hidden />
                            <span>{b}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.li>
                ))}
              </ol>
            </div>
          </div>
        </section>

        {/* ================= PENDIDIKAN ================= */}
        <section id="pendidikan" className="py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <SectionHeader
              kicker="Riwayat Pendidikan"
              title="Pendidikan"
            />
            <div className="mt-12 grid gap-6 md:grid-cols-2">
              {EDUCATIONS.map((ed, i) => (
                <motion.div
                  key={ed.degree}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  variants={fadeUp}
                  className="rounded-3xl border border-toska-100 bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-md"
                >
                  <div className="flex items-start gap-4">
                    <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-toska-100 text-toska-800" aria-hidden>
                      <GraduationCap className="size-6" />
                    </span>
                    <div className="min-w-0">
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-toska-50 border border-toska-200 px-3 py-1 text-xs font-bold text-toska-900">
                        <CalendarDays className="size-3.5" aria-hidden />
                        {ed.period}
                      </span>
                      <h3 className="font-heading mt-3 text-lg font-bold text-ink">{ed.degree}</h3>
                      <p className="mt-0.5 text-sm font-semibold text-toska-800">{ed.school}</p>
                      {ed.note ? <p className="mt-3 text-sm text-ink-soft leading-relaxed">{ed.note}</p> : null}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ================= KEAHLIAN ================= */}
        <section id="keahlian" className="bg-white py-16 sm:py-24 border-y border-toska-100">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <SectionHeader
              kicker="Kompetensi"
              title="Keahlian"
              desc="Penguasaan perangkat kerja utama, didukung keterampilan lintas fungsi."
            />
            <div className="mt-12 grid gap-6 lg:grid-cols-2">
              {/* skill bars */}
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5 }}
                variants={fadeUp}
                className="rounded-3xl border border-toska-100 bg-paper p-7 sm:p-9 shadow-sm"
              >
                <h3 className="font-heading flex items-center gap-2.5 text-lg font-bold text-ink">
                  <span className="grid size-9 place-items-center rounded-xl bg-toska-100 text-toska-800" aria-hidden>
                    <FileSpreadsheet className="size-5" />
                  </span>
                  Keahlian Teknis
                </h3>
                <div className="mt-7 space-y-5">
                  {SKILLS.map((s) => (
                    <SkillBar key={s.label} label={s.label} value={s.value} />
                  ))}
                </div>
                <h4 className="font-heading mt-8 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-ink-soft">
                  <Wrench className="size-4 text-toska-600" aria-hidden />
                  Perangkat Pendukung
                </h4>
                <div className="mt-3 flex flex-wrap gap-2.5">
                  {TOOLS.map((t) => (
                    <Tag key={t}>{t}</Tag>
                  ))}
                </div>
              </motion.div>

              {/* soft skills + bahasa */}
              <div className="flex flex-col gap-6">
                <motion.div
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: 0.08 }}
                  variants={fadeUp}
                  className="rounded-3xl border border-toska-100 bg-paper p-7 sm:p-9 shadow-sm"
                >
                  <h3 className="font-heading flex items-center gap-2.5 text-lg font-bold text-ink">
                    <span className="grid size-9 place-items-center rounded-xl bg-toska-100 text-toska-800" aria-hidden>
                      <HeartHandshake className="size-5" />
                    </span>
                    Keterampilan Komunikasi
                  </h3>
                  <div className="mt-5 flex flex-wrap gap-2.5">
                    {SOFT_SKILLS.map((s) => (
                      <Tag key={s}>{s}</Tag>
                    ))}
                  </div>
                </motion.div>

                <motion.div
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: 0.16 }}
                  variants={fadeUp}
                  className="rounded-3xl bg-toska-800 p-7 sm:p-9 text-white shadow-md shadow-toska-800/20"
                >
                  <h3 className="font-heading flex items-center gap-2.5 text-lg font-bold">
                    <span className="grid size-9 place-items-center rounded-xl bg-white/15" aria-hidden>
                      <Languages className="size-5" />
                    </span>
                    Kemampuan Bahasa
                  </h3>
                  <div className="mt-6 space-y-5">
                    {LANGUAGES.map((l) => (
                      <div key={l.name}>
                        <div className="flex items-center justify-between mb-2 text-sm">
                          <span className="font-semibold">{l.name}</span>
                          <span className="rounded-full bg-white/15 px-3 py-0.5 text-xs font-bold">{l.level}</span>
                        </div>
                        <div className="h-2 rounded-full bg-white/15 overflow-hidden">
                          <motion.div
                            className="h-full rounded-full bg-toska-200"
                            initial={{ width: 0 }}
                            whileInView={{ width: `${l.pct}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1, ease: "easeOut" }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* ================= SERTIFIKASI ================= */}
        <section id="sertifikasi" className="py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <SectionHeader
              kicker="Kredensial"
              title="Sertifikasi & Lisensi"
            />
            <div className="mt-12 grid gap-6 md:grid-cols-3">
              {CERTS.map((c, i) => (
                <motion.div
                  key={c.name}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  variants={fadeUp}
                  className="group rounded-3xl border border-toska-100 bg-white p-7 shadow-sm transition hover:-translate-y-1 hover:border-toska-200 hover:shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <span className="grid size-12 place-items-center rounded-2xl bg-toska-100 text-toska-800 transition group-hover:bg-toska-800 group-hover:text-white" aria-hidden>
                      <BadgeCheck className="size-6" />
                    </span>
                    <Award className="size-5 text-toska-200 transition group-hover:text-toska-600" aria-hidden />
                  </div>
                  <h3 className="font-heading mt-5 text-lg font-bold text-ink">{c.name}</h3>
                  <p className="mt-1 text-sm text-ink-soft leading-relaxed">{c.issuer}</p>
                  <span className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-toska-50 border border-toska-200 px-3 py-1 text-xs font-bold text-toska-900">
                    <CalendarDays className="size-3.5" aria-hidden />
                    {c.period}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ================= KONTAK ================= */}
        <section id="kontak" className="pb-16 sm:pb-24">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5 }}
              variants={fadeUp}
              className="relative overflow-hidden rounded-[2rem] bg-toska-800 px-6 py-14 sm:px-12 sm:py-16 text-center text-white shadow-lg shadow-toska-800/25"
            >
              <div className="dot-grid absolute inset-0 opacity-40" aria-hidden />
              <div className="absolute -top-20 -right-20 size-64 rounded-full bg-toska-600/40 blur-3xl" aria-hidden />
              <div className="relative">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-4 py-1.5 text-xs font-semibold tracking-widest uppercase">
                  <Database className="size-3.5" aria-hidden />
                  Mari Terhubung
                </span>
                <h2 className="font-heading mt-4 text-3xl sm:text-4xl font-extrabold">
                  Diskusikan Kolaborasi Berikutnya
                </h2>
                <p className="mx-auto mt-4 max-w-xl text-toska-200 leading-relaxed">
                  Saya terbuka untuk peluang di bidang operasional produksi, pengolahan data, dan
                  administrasi. Jangan ragu untuk menghubungi saya melalui kanal di bawah ini.
                </p>
                <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 text-left">
                  {CONTACTS.map((c) => {
                    const inner = (
                      <>
                        <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-white/15" aria-hidden>
                          <c.icon className="size-5" />
                        </span>
                        <span className="min-w-0">
                          <span className="block text-xs font-medium text-toska-200">{c.label}</span>
                          <span className="block mt-0.5 text-sm font-semibold break-words">{c.value}</span>
                        </span>
                      </>
                    );
                    const cls =
                      "flex items-start gap-3 rounded-2xl bg-white/10 p-4 backdrop-blur-sm transition hover:bg-white/20";
                    return c.href ? (
                      <a key={c.label} href={c.href} target={c.href.startsWith("http") ? "_blank" : undefined} rel={c.href.startsWith("http") ? "noopener noreferrer" : undefined} className={cls}>
                        {inner}
                      </a>
                    ) : (
                      <div key={c.label} className={cls}>
                        {inner}
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      {/* ================= FOOTER ================= */}
      <footer className="mt-auto border-t border-toska-100 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-6 text-center sm:flex-row sm:px-6 sm:text-left">
          <p className="text-sm text-ink-soft">
            <span className="font-bold text-ink">Ridha Nuzuliani, S.Kom</span>
            <span className="mx-2 text-toska-600" aria-hidden>·</span>
            Staff Operasional Produksi
          </p>
          <p className="text-xs text-ink-soft">
            © {new Date().getFullYear()} Portofolio Profesional. Dibuat dengan sepenuh hati.
          </p>
        </div>
      </footer>

      {/* tombol ke atas */}
      {showTop ? (
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 grid size-12 place-items-center rounded-full bg-toska-800 text-white shadow-lg shadow-toska-800/30 transition hover:-translate-y-1 hover:bg-toska-900"
          aria-label="Kembali ke atas"
        >
          <ArrowUp className="size-5" />
        </button>
      ) : null}
    </div>
  );
}
