import type { Metadata } from "next";
import { Plus_Jakarta_Sans, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "Ridha Nuzuliani, S.Kom — Portofolio",
  description:
    "Portofolio Ridha Nuzuliani, S.Kom — Staff Operasional Produksi. Berpengalaman dalam operasional produksi, analisis data, dan dukungan administrasi operasional.",
  keywords: [
    "Ridha Nuzuliani",
    "Portofolio",
    "Operasional Produksi",
    "Analisis Data",
    "Curriculum Vitae",
  ],
  authors: [{ name: "Ridha Nuzuliani" }],
  openGraph: {
    title: "Ridha Nuzuliani, S.Kom — Portofolio",
    description:
      "Portofolio profesional: pengalaman operasional produksi, pendidikan, keahlian, dan sertifikasi.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${jakarta.variable} ${inter.variable} antialiased bg-background text-foreground font-body`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
